<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {

    public function index()
    {
       
        $this->load->view('header');
        $this->load->view('auth/login');
        $this->load->view('footer');
    }

        
    
    public function ceklogin(){
        $email = $this->input->post('email');
		$password = $this->input->post('password');
		if($_SESSION['email']==$email && $_SESSION['password']==$password)
		{
           

			$this->load->view('header');
         
            
            $this->load->view('auth/berhasillogin');
            
            $this->load->view('footer');
		}
		else
		{
			$this->session->set_flashdata('error','Username & Password salah');
			   $this->load->view('header');
            $this->load->view('auth/login');
            $this->load->view('footer');
		}


    }
    
        public function register()
          {
             $this->load->view('header');
         $this->load->view('auth/register');
          $this->load->view('footer');
    
        }
        public function create (){
                    $this->form_validation->set_rules('email', 'email', 'required');
            $this->form_validation->set_rules('password', 'password', 'required');

            if ($this->form_validation->run() === FALSE)
            {
                 $this->load->view('header');
        $this->load->view('auth/login');
        $this->load->view('footer');

            }
            else
            {
               
                $data = array(
                'email' => $this->input->post('email'),
                'password' =>$this->input->post('password'),
              

            );
                $_SESSION['email'] = $this->input->post('email');
                 $_SESSION['password'] = $this->input->post('password');

                  $this->load->view('header');
        $this->load->view('auth/berhasildaftar');
        $this->load->view('footer');
            }
            

        }


      

        
        public function test ()
        {

            $this->form_validation->set_rules('firstName', 'dedy', 'required');
    $this->form_validation->set_rules('lastName', 'dedy pratama', 'required');
    

    if ($this->form_validation->run() === FALSE)
    {
        $this->load->view('header');
         $this->load->view('auth/register');
          $this->load->view('footer');

    }
    else
    {

          $data = array(
        'firstName' => $this->input->post('firstName'),
        'lastName' =>$this->input->post('lastName'),
        'email' => $this->input->post('email')
    );
         $url = 'https://dummyapi.io/data/v1/user/create';
        $curl = curl_init($url);
        // 1. Set the CURLOPT_RETURNTRANSFER option to true
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

        // 2. Set the CURLOPT_POST option to true for POST request
        curl_setopt($curl, CURLOPT_POST, true);

        // 3. Set the request data as JSON using json_encode function
        curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($data) );

        // 4. Set custom headers for RapidAPI Auth and Content-Type header
        curl_setopt($curl, CURLOPT_HTTPHEADER, [
      
        'app-id: 6357ee974b86e0a6383df082',
        'Content-Type: application/json'
        ]);
        $response = curl_exec($curl);
        curl_close($curl);
        echo $response . PHP_EOL;
       
    }
            // kvstore API url
       

        }

        
    
}
