Silahkan Login
<p>
      
      <?php echo $_SESSION['password'] ?>
    <?php echo $_SESSION['email'] ?>
   
</p>