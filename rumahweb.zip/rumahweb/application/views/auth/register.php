<section class="" style="height:100vh;background-color:  #7cbdfc;display:flex;    align-items: center;">
<div class="container">
    <div class="row justify-content-center">
         <div class="col-lg-12 text-center text-white mb-2">
          <h1>Register</h1>
        </div>
      <div class="col-lg-8 col-8 mb-4" style="background: white;border-radius:8px;">
       
        <form method="post" action="<?= site_url('auth/create')?>">
    <div class="mb-3 mt-2">
    <label for="exampleInputEmail1" class="form-label">Firs Name</label>
    <input type="text" class="form-control" name="firstName" id="exampleInputEmail1" aria-describedby="emailHelp">
    
  </div>
 
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Last Name</label>
    <input type="text" class="form-control" name="lastName" id="exampleInputEmail1" aria-describedby="emailHelp">
    
  </div>
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Email address</label>
    <input type="email" class="form-control" name="email" id="exampleInputEmail1" aria-describedby="emailHelp">
    
  </div>
   <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Password</label>
    <input type="password" class="form-control" name="password" id="exampleInputEmail1" aria-describedby="emailHelp">
    
  </div>
 
  <div class="mb-3 form-check">
    <button type="submit"class="btn btn-primary">Register</button>   
 </div>
 
</form>

      </div>
    </div>
</div>
</section>