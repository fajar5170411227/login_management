<?php
    $ch = curl_init();
curl_setopt_array($ch, array(
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_URL => 'https://dummyapi.io/data/v1/user/',
    CURLOPT_HTTPHEADER => array('app-id: 6357ee974b86e0a6383df082')
));
$response = curl_exec($ch) ;
var_dump($response)
?>
<div class="container">
  <div class="row justify-content-center">

        <div class="col-lg-12" style="text-align: center">

            <table class="table">
                <thead class="thead-dark">
                    <tr>
                        <th scope="col">No</th>
                        <th scope="col">Title</th>
                        <th scope="col">First Name</th>
                        <th scope="col">Last Name</th>
                        
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
         


                    <tr>
                  
                        <th scope="row">1</th>
                        <td>asda</td>

                        <td>asd</td>
                        <td> asd</td>
                                            <td>
                            <a href="" type="button" class="btn btn-warning">
                                edit
                            </a>
                            <a href="" class="btn btn-danger">delete</a>
                        </td>
                        
                       


                    </tr>

                </tbody>
            </table>

            <div style="text-align: left">

                <a href="" class="btn btn-primary">Tambah data</a>
            </div>
        </div>
    </div>
</div>
