
	<div class="container-fluid">
		<div class="row main-content bg-success text-center">
			<div class="col-md-4 text-center company__info">
				
				<h4 class="company_title">Test Rumah Web</h4>
			</div>
			<div class="col-md-8 col-xs-12 col-sm-12 login_form ">
				<div class="container-fluid">
					<div class="row pt-4">
						<h2>Log In</h2>
					</div>
					<div class="row">
					<form method="post" action="<?= site_url('auth/ceklogin')?>" >
							<div class="row">
								<input type="email"  name="email" id="username" class="form__input" placeholder="Username">
							</div>
							<div class="row">
								<!-- <span class="fa fa-lock"></span> -->
								<!-- <input type="password" name="password" id="password" class="form__input" placeholder="Password"> -->
                 <input  type="password" name="password" class="form__input"  oninput="return formvalid()" type="password" required placeholder="Password" id="pass" autocomplete="off" />
                <img class="eyes" src="https://cdn2.iconfinder.com/data/icons/basic-ui-interface-v-2/32/hide-512.png"
                    onclick="show()" id="showimg">
                <span id="vaild-pass"></span>
							</div>
              
							<div class="row">
								<input type="submit" value="Submit" class="btn">
							</div>
						</form>
					</div>
					<div class="row">
						<p>Don't have an account? <a href="<?= site_url('auth/register')?> " style="font-size:12px">Register Here</a></p>
					</div>
				</div>
			</div>
		</div>
	</div>

	
  
  <style>
    .main-content{
	width: 50%;
	border-radius: 20px;
	box-shadow: 0 5px 5px rgba(0,0,0,.4);
	margin: 5em auto;
	display: flex;
}
.company__info{
	background-color: #7cbdfc;
	border-top-left-radius: 20px;
	border-bottom-left-radius: 20px;
	display: flex;
	flex-direction: column;
	justify-content: center;
	color: #fff;
}.eyes{
  width: 44px;
    position: absolute;
    height: 20px;
    top: 282px;
    cursor: pointer;
    right: 391px;
}#vaild-pass{
  color: red;
  margin-right:120px;
}
.fa-android{
	font-size:3em;
}
@media screen and (max-width: 640px) {
	.main-content{width: 90%;}
	.company__info{
		display: none;
	}
	.login_form{
		border-top-left-radius:20px;
		border-bottom-left-radius:20px;
	}
}
@media screen and (min-width: 642px) and (max-width:800px){
	.main-content{width: 70%;}
}
.row > h2{
	color:#7cbdfc;
}
.login_form{
	background-color: #fff;
	border-top-right-radius:20px;
	border-bottom-right-radius:20px;
	border-top:1px solid #ccc;
	border-right:1px solid #ccc;
}
form{
	padding: 0 2em;
}
.form__input{
	width: 100%;
	border:0px solid transparent;
	border-radius: 0;
	border-bottom: 1px solid #aaa;
	padding: 1em .5em .5em;
	padding-left: 2em;
	outline:none;
	margin:1.5em auto;
	transition: all .5s ease;
}
.form__input:focus{
	border-bottom-color: #7cbdfc;
	box-shadow: 0 0 5px rgba(0,80,80,.4); 
	border-radius: 4px;
}
.btn{
	transition: all .5s ease;
	width: 70%;
	border-radius: 30px;
	color:#7cbdfc;
	font-weight: 600;
	background-color: #fff;
	border: 1px solid #7cbdfc;
	margin-top: 1.5em;
	margin-bottom: 1em;
}
.btn:hover, .btn:focus{
	background-color: #7cbdfc;
	color:#fff;
}
  </style>